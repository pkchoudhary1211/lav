<!DOCTYPE html>
<html>
<head>
	


<title>News</title>
	
		  <link rel="stylesheet" href="{!! asset('css/common.css') !!}">
		  
		 </head>
		 @if (session('success'))
    <div class="alert alert-success">
        <p>{{ $session('success') }}<p>
    </div>
    @if(session('success'))
  {{session('success')}}
@endif
@endif 
 @if ($message = Session::get('success'))
           <div class="alert alert-success">
            <p>{{ $message }}</p>
                 </div>
  @endif
	<form action="{{url('/create')}}" method="post" enctype="multipart/form-data">
		{{ csrf_field() }}
		@if(count($errors)>0)
		
		<ul>
			@foreach($errors->all() as $error)
			<li><font color="red">{{ $error }} </font></li>
			@endforeach
		</ul>
		@endif

		<center>
		<div id="infoform" class="formdes">
			<div id="val" class="inside"><center>
				<table  height="200px" class="tab" id="tab">
					<tr>
						<td>Id</td>
						<td><input type="input" name="idd"  /></td>
					</tr>
					<tr>
						<td>Name</td>
						<td><input type="input" placeholder="Enter Your Name" name="name"/></td>
					</tr>
						<tr>
							<td>E-mail</td>
							<td> <input type="email" name="email"/></td>
						</tr>
						<tr>
							<td>Mobile</td>
							<td><input type="number" name="mob" /></td>
						</tr>
						<tr>
							<td>Password</td>
							<td> <input type="password"  name="pass" /></td>
						</tr>
						<tr>
							<td colspan="2"><input type="file" name="image1" accept="image/*" id="uploadfile"/></td>
						</tr>
					
				</table>
			</center>
	</form>

<input type="submit" name="upload"  width="500px" value="upload"/ >
</div>
</div></center>
<br/>
<br/>
<br/>

<center>
	
<form method="POST" action="{{url('/search')}}" enctype="multipart/form-data">
{{csrf_field()}}
<div id="check" class="input-group margin-bottom-sm">       
    <input class="form-control" type="text" name="find" placeholder="Search">
   <input type="submit" name="search" value="Search" style="width: 200px;  border-radius: 5px;">
</div>
</form>
<table class="tg" width="70%">
  <tr>
  
  </br>
    <th  colspan="3" bgcolor="#00FF00" > Total Record Found <?php echo count($img); ?> </th>
    
  </tr>
  
  @foreach($img as $data)

  <tr>
    <td class="tg-yw4l">Id</td>
    <td class="tg-yw4l"> {{ $data->id }}</td>
    <td class="tg-yw4l" rowspan="5"><img src="{{ asset('profiles/'.$data->profile) }}" height="200px"  width="200px" /></td>
  </tr>
  <tr>
    <td class="tg-yw4l">Name</td>
    <td class="tg-yw4l">{{ $data->name }}</td>
   
  </tr>
  <tr>
    <td class="tg-yw4l">Mobile</td>
    <td class="tg-yw4l">{{ $data->mobile }}</td>
  
  </tr>
  <tr>
    <td class="tg-yw4l">Email</td>
    <td class="tg-yw4l">{{ $data->email }}</td>
 
  </tr>
  <tr>
    <td class="tg-yw4l">Action</td>
    <td class="tg-yw4l">  <a onclick="return confirm('Are You Sure to Update')" href="{{url('/papa/'.$data->id)}}">edit </a> | <a onclick="return confirm('Are You Sure to Delete')" href="{{url('/delete/'.$data->id)}}">Delete </a> </td>

  </tr>
  <tr>
  	<td colspan="3"  id="last">Informtion</td>
  </tr>
  @endforeach
</table>
</center>


<br/>
</body>
</html>