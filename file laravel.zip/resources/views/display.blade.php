<!DOCTYPE html>
<html>
<head>
	<title>Display</title>
</head>
<body>
<center>
	<font color="Red" size="22px">Data List</font>
</center>



<form >
@foreach($img as $data) 






    {{ $data->name }}


<br/>


       
         
         


        
@endforeach	
</form>
</body>
</html>