<!DOCTYPE html>
<html>
<head>
	<title>Update Form</title>
</head>
<body>
	 
 
@foreach($imga as $data)

<form action="{{url('/update')}}" method="post" enctype="multipart/form-data" >

{{ csrf_field() }}
 
{{ $data->name }}
<input type="input" name="nameval" value="{{ $data->name }}"/>
<input type="input" name="idd" value="{{ $data->id }}" readonly/>
<input type="submit" name="update" value="Update"/>



</form>


@endforeach
</body>
</html>