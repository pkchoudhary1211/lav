<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use App\Http\Requests;


class datavalue extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }
    public function papaedit($val)
    {

        $val1['imga'] = DB::table('people')->where('id',$val)->get();
        return view('edit',$val1);
    }
    public function dataupdate(Request $request)
    {
        $name=$request->input('nameval');
        $val2=$request->input('idd');
      // DB::update('update table peopl set name=$name where id=$id');

 $data= DB::table('people')
            ->where('id', $val2)
            ->update(['name' => $name]);
            //return view('home',$val);
             $val['img'] = DB::table('people')->get();
   return view('news',$val)->with('success','user Update successfully');
    }
  

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
 

 public function search( Request $req)
  {
//  echo"hello world";
  $srval=$req->input('find');
   $val['img'] = DB::table('people')->where('name','LIKE','%'.$srval.'%')->get();
   return view('news',$val);

 }
}
