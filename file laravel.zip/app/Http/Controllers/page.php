<?php
namespace App\Http\Controllers;
//use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use Illuminate\Http\Request;

class page extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
   public function insertform()
   {
      return view('news');
      echo " hello world";
  }
public function insert(Request $req)
{
 $this->validate($req ,['email'=>'email | required | max:30',

'mob'=>'digits:10| required | max:10',
'pass'=>'required | min:6',
'name'=>'required | max:15']);
 $file=$req->file('image1');
 $destnation='profiles';
 $file->move($destnation,$file->getClientOriginalName());
 $fname=$file->getClientOriginalName();
   
$u_name=$req->input('name');
$u_mob=$req->input('mob');
$u_email=$req->input('email');
$u_pass=$req->input('pass');
//$u_id=$req->input('idd');
//DB::table('people')->insert($data);
DB::insert('insert into people(email,mobile,name,password,profile)values(?,?,?,?,?)',array($u_email,$u_mob,$u_name,$u_pass,$fname));
//DB::insert('insert into imgfile1(name,type) values(?,?)', array($fname,$ftype)); 
//return redirect('/home');
echo " hello world";
 return redirect('news');
//  return redirect()->route('news')->with('massage','Record Inseted  Sucessfully');
//return view('news');
}
public function getdata()
{
// $val = Clients::all();
 $val['img'] = DB::table('people')->get();
   return view('news',$val);

   //return view('people',['val' => $val]);
   //return view ('imgfile1',['images' => $images]);
}
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
    public function display()
    {
     $val['img'] = DB::table('people')->get();
    //$val = DB::select( DB::raw("SELECT * FROM people"));

    return view('display',$val);
       // return View("display");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
    
   // return ('people',['image' =>$image]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function news()
    {
       // $val['img'] = DB::table('people')->get();
    //$val = DB::select( DB::raw("SELECT * FROM people"));

    return view('news',$val);
    }
    public function delete($val)
    {
        DB::table('people')->where('id',$val)->delete();
        return redirect('news');
    }
   
}
