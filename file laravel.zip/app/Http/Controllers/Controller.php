<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
/*
public function insert(Request $req)
{
$u_name=$req->input('name');
$u_mob=$req->input('mob');
$u_email=$req->input('email');
$u_pass=$req->input('pass');
$u_id->$req->input('id1');
$data = array('id' =>$u_id ,'email'=>$u_email,'mobile'=>$u_mob,'name'=>$u_name,'password'=>$u_pass);
DB::table('people')->insert($data);
//DB::insert('insert into people(id,email,mobile,name,password)values(?,?,?,?,?)',array($u_id,$u_email,$u_mob,$u_name,$u_pass));
//DB::insert('insert into imgfile1(name,type) values(?,?)', array($fname,$ftype)); 
//return redirect('/home');
echo " hello world";
  return redirect('/');
//return view('/news');
}   */


}
