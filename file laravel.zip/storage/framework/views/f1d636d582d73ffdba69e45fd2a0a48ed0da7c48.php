<!DOCTYPE html>
<html>
<head>
	<title>Update Form</title>
</head>
<body>
	 
 
<?php $__currentLoopData = $imga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<form action="<?php echo e(url('/update')); ?>" method="post" enctype="multipart/form-data" >

<?php echo e(csrf_field()); ?>

 
<?php echo e($data->name); ?>

<input type="input" name="nameval" value="<?php echo e($data->name); ?>"/>
<input type="input" name="idd" value="<?php echo e($data->id); ?>" readonly/>
<input type="submit" name="update" value="Update"/>



</form>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>