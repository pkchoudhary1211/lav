<!DOCTYPE html>
<html>
<head>
	<title>Display</title>
</head>
<body>
<center>
	<font color="Red" size="22px">Data List</font>
</center>



<form >
<?php $__currentLoopData = $img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 






    <?php echo e($data->name); ?>



<br/>


       
         
         


        
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
</form>
</body>
</html>