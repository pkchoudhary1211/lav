<!DOCTYPE html>
<html>
<head>
	


<title>News</title>
	
		  <link rel="stylesheet" href="<?php echo asset('css/common.css'); ?>">
		  
		 </head>
		 <?php if(session('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($session('success')); ?><p>
    </div>
    <?php if(session('success')): ?>
  <?php echo e(session('success')); ?>

<?php endif; ?>
<?php endif; ?> 
 <?php if($message = Session::get('success')): ?>
           <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
                 </div>
  <?php endif; ?>
	<form action="<?php echo e(url('/create')); ?>" method="post" enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>

		<?php if(count($errors)>0): ?>
		
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><font color="red"><?php echo e($error); ?> </font></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		<?php endif; ?>

		<center>
		<div id="infoform" class="formdes">
			<div id="val" class="inside"><center>
				<table  height="200px" class="tab" id="tab">
					<tr>
						<td>Id</td>
						<td><input type="input" name="idd"  /></td>
					</tr>
					<tr>
						<td>Name</td>
						<td><input type="input" placeholder="Enter Your Name" name="name"/></td>
					</tr>
						<tr>
							<td>E-mail</td>
							<td> <input type="email" name="email"/></td>
						</tr>
						<tr>
							<td>Mobile</td>
							<td><input type="number" name="mob" /></td>
						</tr>
						<tr>
							<td>Password</td>
							<td> <input type="password"  name="pass" /></td>
						</tr>
						<tr>
							<td colspan="2"><input type="file" name="image1" accept="image/*" id="uploadfile"/></td>
						</tr>
					
				</table>
			</center>
	</form>

<input type="submit" name="upload"  width="500px" value="upload"/ >
</div>
</div></center>
<br/>
<br/>
<br/>

<center>
	
<form method="POST" action="<?php echo e(url('/search')); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>

<div id="check" class="input-group margin-bottom-sm">       
    <input class="form-control" type="text" name="find" placeholder="Search">
   <input type="submit" name="search" value="Search" style="width: 200px;  border-radius: 5px;">
</div>
</form>
<table class="tg" width="70%">
  <tr>
  
  </br>
    <th  colspan="3" bgcolor="#00FF00" > Total Record Found <?php echo count($img); ?> </th>
    
  </tr>
  
  <?php $__currentLoopData = $img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <tr>
    <td class="tg-yw4l">Id</td>
    <td class="tg-yw4l"> <?php echo e($data->id); ?></td>
    <td class="tg-yw4l" rowspan="5"><img src="<?php echo e(asset('profiles/'.$data->profile)); ?>" height="200px"  width="200px" /></td>
  </tr>
  <tr>
    <td class="tg-yw4l">Name</td>
    <td class="tg-yw4l"><?php echo e($data->name); ?></td>
   
  </tr>
  <tr>
    <td class="tg-yw4l">Mobile</td>
    <td class="tg-yw4l"><?php echo e($data->mobile); ?></td>
  
  </tr>
  <tr>
    <td class="tg-yw4l">Email</td>
    <td class="tg-yw4l"><?php echo e($data->email); ?></td>
 
  </tr>
  <tr>
    <td class="tg-yw4l">Action</td>
    <td class="tg-yw4l">  <a onclick="return confirm('Are You Sure to Update')" href="<?php echo e(url('/papa/'.$data->id)); ?>">edit </a> | <a onclick="return confirm('Are You Sure to Delete')" href="<?php echo e(url('/delete/'.$data->id)); ?>">Delete </a> </td>

  </tr>
  <tr>
  	<td colspan="3"  id="last">Informtion</td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</center>


<br/>
</body>
</html>